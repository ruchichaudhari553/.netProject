namespace EmployeeManagementApp.Models
{
    public class Clerk : Employee
    {
        public string ReportsTo { get; set; } = "";
    }
}
