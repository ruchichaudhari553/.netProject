using System;

namespace EmployeeManagementApp.Models
{
    public class Employee
    {
        public int Id { get; set; }
        public string? MiddleName { get; set; }  // nullable
        public string FullName { get; set; } = "";
        public string Designation { get; set; } = "";
        public string Department { get; set; } = "";
        public DateTime HireDate { get; set; }
        public decimal Salary { get; set; }

        // Direct method instead of extension
        public int GetYearsOfExperience()
        {
            var today = DateTime.Today;
            int years = today.Year - HireDate.Year;
            if (HireDate.AddYears(years) > today)
                years--;
            return years < 0 ? 0 : years;
        }
    }
}
