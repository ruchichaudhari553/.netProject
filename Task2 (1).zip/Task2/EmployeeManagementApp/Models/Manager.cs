namespace EmployeeManagementApp.Models
{
    public class Manager : Employee
    {
        public string DepartmentManaged { get; set; } = "";
    }
}
