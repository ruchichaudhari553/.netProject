using Microsoft.AspNetCore.Mvc;
using EmployeeManagementApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeManagementApp.Controllers
{
    public class HomeController : Controller
    {
        private static readonly List<Employee> employees = new()
        {
            new Employee { Id = 1, FullName = "John Doe", Designation = "Manager", Department = "HR", HireDate = DateTime.Now.AddYears(-8), Salary = 5000 },
            new Employee { Id = 2, FullName = "Jane Smith", Designation = "Clerk", Department = "IT", HireDate = DateTime.Now.AddYears(-3), Salary = 3000 },
            new Employee { Id = 3, FullName = "Alice Brown", Designation = "Manager", Department = "IT", HireDate = DateTime.Now.AddYears(-6), Salary = 6000 },
            new Employee { Id = 4, FullName = "Bob White", Designation = "Clerk", Department = "Finance", HireDate = DateTime.Now.AddYears(-2), Salary = 2500 },
            new Employee { Id = 5, FullName = "Mark Green", Designation = "Manager", Department = "Finance", HireDate = DateTime.Now.AddYears(-9), Salary = 7000 },
            new Employee { Id = 6, FullName = "Sophie Lee", Designation = "Clerk", Department = "HR", HireDate = DateTime.Now.AddYears(-4), Salary = 2800 },
            new Employee { Id = 7, FullName = "Tom Hall", Designation = "Clerk", Department = "IT", HireDate = DateTime.Now.AddYears(-1), Salary = 2200 },
            new Employee { Id = 8, FullName = "Eva Kim", Designation = "Manager", Department = "Sales", HireDate = DateTime.Now.AddYears(-5), Salary = 5500 },
            new Employee { Id = 9, FullName = "Luke Park", Designation = "Clerk", Department = "Sales", HireDate = DateTime.Now.AddYears(-2), Salary = 2700 },
            new Employee { Id = 10, FullName = "Nina Patel", Designation = "Manager", Department = "IT", HireDate = DateTime.Now.AddYears(-10), Salary = 8000 }
        };

        public IActionResult Index(string? dept)
        {
            // Query string filter
            var filtered = string.IsNullOrEmpty(dept)
                ? employees
                : employees.Where(e => e.Department.Equals(dept, StringComparison.OrdinalIgnoreCase)).ToList();

            ViewBag.FormToken = Guid.NewGuid().ToString();

            // Async fetch salary conversion
            var rates = GetCurrencyRatesAsync().Result;
            ViewBag.Rates = rates;

            // Cookie for last login
            Response.Cookies.Append("LastLogin", DateTime.Now.ToString());

            // Session for example employee
            HttpContext.Session.SetString("EmployeeId", "1234");

            return View(filtered);
        }

        public IActionResult Welcome()
        {
            string greeting = GetGreeting();
            ViewBag.Greeting = greeting;
            return View();
        }

        public IActionResult MyView()
        {
            ViewBag.CompanyName = "TechNova Pvt Ltd";
            ViewBag.Description = "A growing IT company specializing in software solutions.";
            ViewBag.Founded = 2012;
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult SubmitForm(string FormToken)
        {
            ViewBag.Message = $"Form submitted successfully with token: {FormToken}";
            return RedirectToAction("Index");
        }

        private async Task<Dictionary<string, decimal>> GetCurrencyRatesAsync()
        {
            await Task.Delay(100); // simulate async fetch
            return new Dictionary<string, decimal> { { "INR", 83.0m } };
        }

        private string GetGreeting()
        {
            var hour = DateTime.Now.Hour;
            if (hour < 12) return "Good Morning!";
            if (hour < 18) return "Good Afternoon!";
            return "Good Evening!";
        }
    }
}
